
function filterEvents(){const q=(document.querySelector('#filter')?.value||'').toLowerCase();document.querySelectorAll('.event').forEach(e=>e.classList.toggle('hidden',q&&!e.dataset.search.toLowerCase().includes(q)));}
function setOpen(open){document.querySelectorAll('.event').forEach(e=>e.open=open);}
function filterRows(){const q=(document.querySelector('#taskFilter')?.value||'').toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.classList.toggle('hidden',!r.innerText.toLowerCase().includes(q)));}
